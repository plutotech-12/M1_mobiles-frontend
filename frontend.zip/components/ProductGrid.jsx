"use client";

import { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import { Loader2 } from "lucide-react";
import api from "../lib/api";

export default function ProductGrid({ title, categorySlug, onAddToCart }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    fetchProducts();
  }, [categorySlug, filter]);

  const fetchProducts = async () => {
    try {
      setLoading(true);

      let query = "";

      if (categorySlug) {
        query += `?category=${categorySlug}`;
      }

      if (categorySlug?.toLowerCase() === "phones" && filter !== "all") {
        query += `${query ? "&" : "?"}subCategory=${
          filter === "new" ? "New" : "Refurbished"
        }`;
      }

      // ⭐ FIXED
      const res = await api.get(`/products${query}`);
      setProducts(res.data);

    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setLoading(false);
    }
  };

  // ⭐ FIXED — Case insensitive
  const showPhoneFilters = categorySlug?.toLowerCase() === "phones";

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Loader2 className="h-12 w-12 text-orange-600 animate-spin" />
      </div>
    );
  }

  return (
    <section className="py-12 sm:py-16 bg-gray-50">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6">

        {/* Header + Filters */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900">
            {title}
          </h2>

          {/* ⭐ FILTER BUTTONS SHOW NOW */}
          {showPhoneFilters && (
            <div className="flex space-x-2 bg-white rounded-lg p-1 shadow-sm">
              {["all", "new", "refurbished"].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 sm:px-6 py-2 rounded-md font-medium transition-colors ${
                    filter === f
                      ? "bg-orange-600 text-white"
                      : "text-gray-600 hover:text-orange-600"
                  }`}
                >
                  {f === "all"
                    ? "All"
                    : f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {products.map((product) => (
            <ProductCard
              key={product._id}
              product={product}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
