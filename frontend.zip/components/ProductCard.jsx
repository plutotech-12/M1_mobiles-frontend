"use client";

import Link from "next/link";
import { ShoppingCart, CheckCircle } from "lucide-react";

// The best product card we will use across the project
export default function ProductCard({ product }) {
  const discount = product.original_price
    ? Math.round(
        ((product.original_price - product.price) / product.original_price) * 100
      )
    : 0;

  // Handle multiple images (use first)
  const mainImage = Array.isArray(product.image)
    ? product.image[0]
    : product.image || product.image_url;

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group border border-gray-100">

      {/* IMAGE WRAPPER */}
      <Link href={`/products/${product._id}`} className="relative block overflow-hidden">
        <img
          src={mainImage}
          alt={product.name}
          className="w-full h-56 object-contain bg-white p-4 group-hover:scale-110 transition-transform duration-500"
        />


        {/* CONDITION BADGES */}
        {product.subCategory === "Refurbished" && (
          <span className="absolute top-4 left-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white px-3 py-1 rounded-full text-xs font-semibold shadow">
            Refurbished
          </span>
        )}

        {product.subCategory === "New" && (
          <span className="absolute top-4 left-4 bg-gradient-to-r from-green-500 to-green-600 text-white px-3 py-1 rounded-full text-xs font-semibold shadow">
            New
          </span>
        )}

        {product.subCategory === "Like New" && (
          <span className="absolute top-4 left-4 bg-blue-600 text-white px-3 py-1 rounded-full text-xs shadow">
            Like New
          </span>
        )}

        {product.subCategory === "Demo-OpenBox" && (
          <span className="absolute top-4 left-4 bg-yellow-500 text-white px-3 py-1 rounded-full text-xs shadow">
            Demo / Open Box
          </span>
        )}


        {/* DISCOUNT BADGE */}
        {discount > 0 && (
          <span className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow">
            {discount}% OFF
          </span>
        )}
      </Link>

      {/* CONTENT */}
      <div className="p-5 space-y-3">

        <Link href={`/products/${product._id}`} className="block hover:opacity-80 transition-opacity">
          <p className="text-xs text-gray-500 uppercase tracking-wide">{product.brand}</p>

          <h3 className="text-lg font-semibold text-gray-900 mt-1 leading-snug line-clamp-2">
            {product.name}
          </h3>

          {product.description && (
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
              {product.description}
            </p>
          )}
          {/* Rating */}
          <div className="flex items-center gap-1 mt-1">
            {product.ratingsAverage > 0 ? (
              <>
                {Array.from({ length: 5 }, (_, i) => (
                  <svg
                    key={i}
                    viewBox="0 0 20 20"
                    fill={i < Math.round(product.ratingsAverage) ? "currentColor" : "none"}
                    stroke="currentColor"
                    className={`w-4 h-4 ${i < Math.round(product.ratingsAverage) ? "text-yellow-400" : "text-gray-300"}`}
                  >
                    <path d="M10 1.5l2.59 5.25L18 7.6l-4 3.9L15.18 18 10 15.1 4.82 18 6 11.5 2 7.6l5.41-.85L10 1.5z" />
                  </svg>
                ))}

                <span className="text-xs text-gray-600 ml-1">
                  ({product.ratingsAverage.toFixed(1)})
                </span>
              </>
            ) : (
              <span className="text-xs text-gray-400">No ratings yet</span>
            )}
          </div>
        </Link>

        {/* PRICE + CART */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">

          {/* PRICE */}
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-orange-600">
                ₹{product.price.toLocaleString("en-IN")}
              </span>

              {product.original_price && (
                <span className="text-xs text-gray-400 line-through">
                  ₹{product.original_price.toLocaleString("en-IN")}
                </span>
              )}
            </div>

            {product.stock > 0 ? (
              <div className="flex items-center gap-1 text-green-600 text-xs mt-1">
                <CheckCircle className="h-4 w-4" />
                <span>In Stock ({product.stock})</span>
              </div>
            ) : (
              <span className="text-red-600 text-xs mt-1">Out of Stock</span>
            )}
          </div>

          {/* ADD TO CART */}
          <button
            onClick={() => {
              // Fire your existing cart event
              document.dispatchEvent(new CustomEvent("addToCart", { detail: product }));

              // Trigger cart shake animation
              const cartIcon = document.querySelector("#cart-icon");
              if (cartIcon) {
                cartIcon.classList.add("cart-shake");
                setTimeout(() => cartIcon.classList.remove("cart-shake"), 500);
              }

              // Toast notification
              const toast = document.createElement("div");
              toast.innerText = "Added to Cart!";
              toast.className = "fixed top-5 right-5 bg-orange-600 text-white px-4 py-2 rounded-lg shadow-lg animate-fade-in z-50";
              document.body.appendChild(toast);
              setTimeout(() => toast.remove(), 1500);
            }}

            className="bg-gradient-to-r from-orange-600 to-orange-500 text-white p-3 rounded-lg 
              hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 
              disabled:bg-gray-300 disabled:text-gray-500 disabled:hover:translate-y-0"
          >
            <ShoppingCart className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
