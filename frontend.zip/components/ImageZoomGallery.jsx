"use client";

import { useEffect, useRef, useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

/**
 * ImageZoomGallery - improved / fixed
 * props:
 * - images: string[]
 * - selectedImage, setSelectedImage
 */
export default function ImageZoomGallery({ images = [], selectedImage, setSelectedImage }) {
  const imgRef = useRef(null);
  const containerRef = useRef(null);
  const [isHovering, setIsHovering] = useState(false); // true when pointer inside image
  const [lens, setLens] = useState({ display: "none", left: 0, top: 0, w: 0, h: 0 });
  const [zoomBg, setZoomBg] = useState({ image: "", size: "cover", pos: "50% 50%" });
  const [modalOpen, setModalOpen] = useState(false);
  const [modalIndex, setModalIndex] = useState(images.indexOf(selectedImage || images[0]) || 0);
  const zoomScale = 2.6;

  useEffect(() => {
    // sync modal index when external selectedImage changes
    const idx = images.indexOf(selectedImage);
    if (idx >= 0) setModalIndex(idx);
  }, [selectedImage, images]);

  useEffect(() => {
    // when modal index changes, update selectedImage
    if (images[modalIndex]) setSelectedImage(images[modalIndex]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalIndex]);

  // Called on pointer move
  const onPointerMove = (e) => {
    const img = imgRef.current;
    const container = containerRef.current;
    if (!img || !container) return;

    // get pointer coords relative to image
    const rect = img.getBoundingClientRect();
    const clientX = e.clientX ?? (e.touches && e.touches[0]?.clientX);
    const clientY = e.clientY ?? (e.touches && e.touches[0]?.clientY);
    if (clientX == null || clientY == null) return;

    const offsetX = clientX - rect.left;
    const offsetY = clientY - rect.top;

    // hide if outside
    if (offsetX < 0 || offsetY < 0 || offsetX > rect.width || offsetY > rect.height) {
      setLens((l) => ({ ...l, display: "none" }));
      setIsHovering(false);
      return;
    }

    // show lens
    setIsHovering(true);

    // lens size: 20-26% of image
    const lensW = Math.max(80, Math.min(240, Math.round(rect.width * 0.22)));
    const lensH = Math.max(80, Math.min(240, Math.round(rect.height * 0.22)));

    // clamp lens position
    const left = Math.max(0, Math.min(rect.width - lensW, offsetX - lensW / 2));
    const top = Math.max(0, Math.min(rect.height - lensH, offsetY - lensH / 2));

    setLens({
      display: "block",
      left,
      top,
      w: lensW,
      h: lensH,
    });

    // compute background for zoom window
    const naturalW = img.naturalWidth || rect.width;
    const naturalH = img.naturalHeight || rect.height;

    // percent position (so background-position stays correct regardless of bg-size)
    const px = (offsetX / rect.width) * 100;
    const py = (offsetY / rect.height) * 100;

    // background size in px to maintain crispness
    const bgW = Math.round(naturalW * zoomScale);
    const bgH = Math.round(naturalH * zoomScale);

    setZoomBg({
      image: selectedImage,
      size: `${bgW}px ${bgH}px`,
      pos: `${px}% ${py}%`,
    });
  };

  const onPointerLeave = () => {
    setIsHovering(false);
    setLens((l) => ({ ...l, display: "none" }));
  };

  // open modal (tap on mobile or click)
  const openModal = (idx) => {
    setModalIndex(idx);
    setModalOpen(true);
  };

  // helpers for modal navigation
  const prevModal = () => setModalIndex((i) => Math.max(0, i - 1));
  const nextModal = () => setModalIndex((i) => Math.min(images.length - 1, i + 1));

  return (
    <div className="flex gap-6 items-start">
      {/* Vertical thumbnails */}
      <div className="flex flex-col gap-4">
        {images.map((img, index) => (
          <button
            key={index}
            onClick={() => {
              setSelectedImage(img);
              setModalIndex(index);
            }}
            onDoubleClick={() => openModal(index)}
            className={`border-2 rounded-xl p-1 bg-white shadow-sm w-20 h-20 flex items-center justify-center transition ${
              selectedImage === img ? "border-orange-500 scale-105" : "border-gray-200"
            }`}
            aria-label={`Thumbnail ${index + 1}`}
          >
            <img src={img} className="object-contain h-full w-full" alt={`thumb-${index}`} draggable={false} />
          </button>
        ))}
      </div>

      {/* Main image + lens */}
      <div className="flex-1 flex gap-6 items-start">
        <div
          ref={containerRef}
          className="relative bg-white rounded-2xl border shadow-lg flex items-center justify-center overflow-hidden"
          style={{ width: 520, minHeight: 440 }}
          onMouseMove={onPointerMove}
          onMouseEnter={() => setIsHovering(true)}
          onMouseLeave={onPointerLeave}
          onTouchStart={() => { /* on touch, don't show lens - open modal instead */ }}
          onClick={() => openModal(images.indexOf(selectedImage))}
        >
          <img
            ref={imgRef}
            src={selectedImage}
            alt="product"
            className="max-h-[480px] w-auto object-contain select-none"
            draggable={false}
            onLoad={() => {
              // small safety: recalc zoomBg when image natural size becomes available
              const img = imgRef.current;
              if (!img) return;
              setZoomBg((z) => ({ ...z, image: selectedImage }));
            }}
          />

        </div>

        {/* Zoom window (float to the right like Amazon) */}
        <div
        className="hidden lg:block bg-white rounded-2xl border shadow-xl"
        style={{
            position: "absolute",     // <-- THIS fixes the mixing bug
            left: "580px",            // <-- adjust if needed
            top: "200px",
            width: "360px",
            height: "360px",
            overflow: "hidden",
            zIndex: 999,              // <-- ensures it floats above WITHOUT covering text
            display: isHovering ? "block" : "none",
            backgroundColor: "white",
        }}
        >
        <div
            style={{
            width: "100%",
            height: "100%",
            backgroundRepeat: "no-repeat",
            backgroundImage: `url("${zoomBg.image || selectedImage}")`,
            backgroundSize: zoomBg.size || "cover",
            backgroundPosition: zoomBg.pos || "50% 50%",
            transition: "background-position 40ms linear, background-size 120ms linear",
            }}
        />
        </div>


      </div>

      {/* Modal: fullscreen carousel */}
      {modalOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 p-4">
          <div className="relative bg-white rounded-xl max-w-4xl w-full overflow-hidden">
            <button onClick={() => setModalOpen(false)} className="absolute right-4 top-4 bg-white rounded-full p-2 shadow" aria-label="close">
              <X />
            </button>

            <div className="flex items-center">
              <button onClick={prevModal} className="p-6 flex items-center justify-center">
                <ChevronLeft />
              </button>

              <div className="flex-1 p-6 flex items-center justify-center">
                <img src={images[modalIndex]} alt="modal" className="max-h-[80vh] object-contain" />
              </div>

              <button onClick={nextModal} className="p-6 flex items-center justify-center">
                <ChevronRight />
              </button>
            </div>

            <div className="flex gap-3 p-4 overflow-x-auto border-t">
              {images.map((img, i) => (
                <button key={i} onClick={() => setModalIndex(i)} className={`w-20 h-20 flex items-center justify-center rounded-md p-1 border ${i === modalIndex ? "border-orange-500" : "border-gray-200"}`}>
                  <img src={img} className="object-contain w-full h-full" alt={`mthumb-${i}`} draggable={false} />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
