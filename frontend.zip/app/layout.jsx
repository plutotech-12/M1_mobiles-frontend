"use client";

import { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "../context/AuthContext";
import "./globals.css";

import Header from "../components/Header";
import Footer from "../components/Footer";
import Cart from "../components/Cart";
import api from "../lib/api";

// ================================
// INTERNAL LAYOUT COMPONENT
// ================================
function LayoutContent({ children }) {
  const [cartOpen, setCartOpen] = useState(false);

  // ⭐ Get user + global cart from AuthContext
  const { user, cart, setCart } = useAuth();

  // ⭐ Listen for "openCart" event (Header icon)
  useEffect(() => {
    const openCartHandler = () => setCartOpen(true);
    document.addEventListener("openCart", openCartHandler);

    return () => document.removeEventListener("openCart", openCartHandler);
  }, []);

  // ⭐ GLOBAL ADD-TO-CART EVENT HANDLER
  useEffect(() => {
    const handler = async (event) => {
      const product = event.detail;

      if (!user) {
        alert("Please login to add items to cart.");
        return;
      }

      try {
        // Add item to backend cart
        await api.post("/cart", {
          productId: product._id,
          quantity: 1,
        });

        // Reload updated cart
        const res = await api.get("/cart");
        setCart(res.data);

      } catch (err) {
        console.error("Add to cart failed:", err);
      }
    };

    document.addEventListener("addToCart", handler);
    return () => document.removeEventListener("addToCart", handler);
  }, [user, setCart]);

  // ================================
  // RENDER LAYOUT
  // ================================
  return (
    <>
      {/* GLOBAL HEADER */}
      <Header
        cartCount={cart?.length || 0}
        onCartClick={() => setCartOpen(true)}
        onSearch={(query) => {
          document.dispatchEvent(new CustomEvent("searchEvent", { detail: query }));
        }}
      />

      {/* PAGE CONTENT */}
      <main className="min-h-screen bg-white">{children}</main>

      {/* GLOBAL CART DRAWER */}
      <Cart
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cart || []}
        onUpdateQuantity={async (productId, qty) => {
          try {
            await api.put("/cart", { productId, quantity: qty });
            const res = await api.get("/cart");
            setCart(res.data);
          } catch (err) {
            console.error("Update cart failed:", err);
          }
        }}
        onRemove={async (productId) => {
          try {
            await api.delete("/cart", { data: { productId } });
            const res = await api.get("/cart");
            setCart(res.data);
          } catch (err) {
            console.error("Remove cart failed:", err);
          }
        }}
      />

      {/* FOOTER */}
      <Footer />
    </>
  );
}

// ================================
// MAIN ROOT LAYOUT EXPORT
// ================================
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <LayoutContent>{children}</LayoutContent>
        </AuthProvider>
      </body>
    </html>
  );
}
